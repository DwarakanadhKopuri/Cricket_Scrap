# Scraping

### Batting Career Scraper
The python program scrapes data from the stats pages of priemer sports website espncricinfo, 
and returns a json data containing extensive data player's career match-by-match.

![Scraping Data](https://user-images.githubusercontent.com/21276922/56100349-48c0a180-5f35-11e9-93be-b8274fb89820.png)
